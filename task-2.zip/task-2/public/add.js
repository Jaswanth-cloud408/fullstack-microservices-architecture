function addEmployee(){

let name=document.getElementById("name").value;
let department=document.getElementById("department").value;
let date=document.getElementById("date").value;

if(!name || !department || !date){
alert("Fill all fields");
return;
}

fetch("/api/add-employee",{
method:"POST",
headers:{
"Content-Type":"application/json"
},
body:JSON.stringify({name,department,joining_date:date})
})
.then(res=>res.json())
.then(()=>{
alert("Employee Added ✅");

document.getElementById("name").value="";
document.getElementById("date").value="";
});
}