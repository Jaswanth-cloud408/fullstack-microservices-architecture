const express = require("express");
const { body, validationResult } = require("express-validator");
const path = require("path");

const app = express();

// Middleware
app.use(express.json());

// 🔥 IMPORTANT: Serve static files
app.use(express.static(path.join(__dirname, "public")));

// ALSO explicitly send index.html (extra safety)
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

/* VALIDATION */
const userValidation = [
  body("name").notEmpty().withMessage("Name is required"),
  body("email").isEmail().withMessage("Valid email required"),
  body("age").isInt({ min: 1 }).withMessage("Age must be positive"),
];

/* ROUTE */
app.post("/user", userValidation, (req, res, next) => {
  const errors = validationResult(req);

  if (!errors.isEmpty()) {
    return res.status(400).json({
      status: "fail",
      errors: errors.array(),
    });
  }

  try {
    const { name, email, age } = req.body;

    if (name === "error") {
      throw new Error("Manual error triggered");
    }

    res.json({
      status: "success",
      message: "User created successfully",
    });

  } catch (err) {
    next(err);
  }
});

/* GLOBAL ERROR HANDLER */
app.use((err, req, res, next) => {
  res.status(500).json({
    status: "error",
    message: err.message,
  });
});

/* SERVER */
app.listen(3000, () => {
  console.log("✅ Server running at http://localhost:3000");
});