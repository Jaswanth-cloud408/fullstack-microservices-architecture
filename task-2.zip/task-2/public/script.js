let sortType = "";

/* Load Employee Data */
function loadData() {

let department = document.getElementById("departmentFilter").value;

fetch(`/api/employees?sort=${sortType}&department=${department}`)
.then(response => response.json())
.then(data => {

let rows = "";

data.forEach(emp => {

let formattedDate = new Date(emp.joining_date).toLocaleDateString();

rows += `
<tr>
<td>${emp.id}</td>
<td>${emp.name}</td>
<td>${emp.department}</td>
<td>${formattedDate}</td>
</tr>
`;

});

document.getElementById("tableData").innerHTML = rows;

})
.catch(error => {
console.error("Error fetching data:", error);
});

}

/* Sorting */
function sortName() {
sortType = "name";
loadData();
}

function sortDate() {
sortType = "date";
loadData();
}

/* Filter */
document.getElementById("departmentFilter").addEventListener("change", loadData);

/* Department Count */
function departmentCount() {

fetch("/api/department-count")
.then(response => response.json())
.then(data => {

let list = "";

data.forEach(d => {
list += `<li>${d.department} : ${d.total}</li>`;
});

document.getElementById("deptCount").innerHTML = list;

})
.catch(error => {
console.error("Error fetching department count:", error);
});

}

/* Add Employee */
function addEmployee() {

let name = document.getElementById("name").value.trim();
let department = document.getElementById("department").value;
let date = document.getElementById("date").value;

/* Validation */
if(name === "" || date === ""){
alert("Please fill all fields");
return;
}

fetch("/api/add-employee", {

method: "POST",

headers: {
"Content-Type": "application/json"
},

body: JSON.stringify({
name: name,
department: department,
joining_date: date
})

})
.then(response => response.json())
.then(data => {

alert("Employee Added Successfully ✅");

/* Clear inputs */
document.getElementById("name").value = "";
document.getElementById("date").value = "";

/* Refresh data */
loadData();
departmentCount();

})
.catch(error => {
console.error("Error adding employee:", error);
});

}

/* Initial Load */
loadData();
departmentCount();