async function addUser() {
  const name = document.getElementById("username").value;
  const output = document.getElementById("output");

  try {
    const res = await fetch("http://localhost:3001/users", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ name })
    });

    const data = await res.json();

    if (!res.ok) {
      output.innerHTML = `<span style="color:red">${data.message}</span>`;
    } else {
      output.innerHTML = `<span style="color:green">${data.message}</span>`;
    }

  } catch (err) {
    output.innerHTML = "❌ User service not running";
  }
}

async function addProduct() {
  const name = document.getElementById("productname").value;
  const output = document.getElementById("output");

  try {
    const res = await fetch("http://localhost:3002/products", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ name })
    });

    const data = await res.json();

    if (!res.ok) {
      output.innerHTML = `<span style="color:red">${data.message}</span>`;
    } else {
      output.innerHTML = `<span style="color:green">${data.message}</span>`;
    }

  } catch (err) {
    output.innerHTML = "❌ Product service not running";
  }
}