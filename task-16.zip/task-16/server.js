const express = require("express");
const { createProxyMiddleware } = require("http-proxy-middleware");

/* ===============================
   STUDENT SERVICE - INSTANCE 1
=================================*/
const studentService1 = express();
studentService1.use(express.json());

let students1 = [];

studentService1.get("/students", (req, res) => {
  res.json({
    instance: "Student Service 1",
    port: 3001,
    data: students1
  });
});

studentService1.post("/students", (req, res) => {
  students1.push(req.body);
  res.json({
    instance: "Student Service 1",
    msg: "Added",
    data: students1
  });
});

studentService1.listen(3001, () =>
  console.log("✅ Student Service 1 running on 3001")
);

/* ===============================
   STUDENT SERVICE - INSTANCE 2
=================================*/
const studentService2 = express();
studentService2.use(express.json());

let students2 = [];

studentService2.get("/students", (req, res) => {
  res.json({
    instance: "Student Service 2",
    port: 3002,
    data: students2
  });
});

studentService2.post("/students", (req, res) => {
  students2.push(req.body);
  res.json({
    instance: "Student Service 2",
    msg: "Added",
    data: students2
  });
});

studentService2.listen(3002, () =>
  console.log("✅ Student Service 2 running on 3002")
);

/* ===============================
   EMPLOYEE SERVICE - INSTANCE 1
=================================*/
const employeeService1 = express();
employeeService1.use(express.json());

let employees1 = [];

employeeService1.get("/employees", (req, res) => {
  res.json({
    instance: "Employee Service 1",
    port: 4001,
    data: employees1
  });
});

employeeService1.post("/employees", (req, res) => {
  employees1.push(req.body);
  res.json({
    instance: "Employee Service 1",
    msg: "Added",
    data: employees1
  });
});

employeeService1.listen(4001, () =>
  console.log("✅ Employee Service 1 running on 4001")
);

/* ===============================
   EMPLOYEE SERVICE - INSTANCE 2
=================================*/
const employeeService2 = express();
employeeService2.use(express.json());

let employees2 = [];

employeeService2.get("/employees", (req, res) => {
  res.json({
    instance: "Employee Service 2",
    port: 4002,
    data: employees2
  });
});

employeeService2.post("/employees", (req, res) => {
  employees2.push(req.body);
  res.json({
    instance: "Employee Service 2",
    msg: "Added",
    data: employees2
  });
});

employeeService2.listen(4002, () =>
  console.log("✅ Employee Service 2 running on 4002")
);

/* ===============================
   API GATEWAY
=================================*/
const app = express();

/* HOME */
app.get("/", (req, res) => {
  res.send("🚀 API Gateway Running");
});

/* Load Balancer Counters */
let studentIndex = 0;
let employeeIndex = 0;

/* Services */
const studentServices = [
  "http://localhost:3001",
  "http://localhost:3002"
];

const employeeServices = [
  "http://localhost:4001",
  "http://localhost:4002"
];

/* STUDENT ROUTE */
app.use("/students", (req, res, next) => {
  const target = studentServices[studentIndex];
  studentIndex = (studentIndex + 1) % studentServices.length;

  console.log("🔥 Student routed to:", target);

  createProxyMiddleware({
    target,
    changeOrigin: true
  })(req, res, next);
});

/* EMPLOYEE ROUTE */
app.use("/employees", (req, res, next) => {
  const target = employeeServices[employeeIndex];
  employeeIndex = (employeeIndex + 1) % employeeServices.length;

  console.log("🔥 Employee routed to:", target);

  createProxyMiddleware({
    target,
    changeOrigin: true
  })(req, res, next);
});

/* START GATEWAY */
app.listen(5000, () => {
  console.log("🚀 API Gateway running at http://localhost:5000");
});