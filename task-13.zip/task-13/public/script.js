async function submitData() {
  const name = document.getElementById("name").value;
  const email = document.getElementById("email").value;
  const age = document.getElementById("age").value;

  const responseDiv = document.getElementById("response");

  try {
    const res = await fetch("http://localhost:3000/user", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ name, email, age })
    });

    const data = await res.json();

    if (res.status !== 200) {
      responseDiv.innerHTML = `<span style="color:red">${JSON.stringify(data)}</span>`;
    } else {
      responseDiv.innerHTML = `<span style="color:green">${data.message}</span>`;
    }

  } catch (error) {
    responseDiv.innerHTML = `<span style="color:red">Server error</span>`;
  }
}