const express = require("express");
const cors = require("cors");

const app = express();

app.use(express.json());
app.use(cors());

let products = [];

// ✅ Root route (fixes "Cannot GET /")
app.get("/", (req, res) => {
  res.send("Product Service Running ✅");
});

// Get products
app.get("/products", (req, res) => {
  res.json(products);
});

// Add product
app.post("/products", (req, res) => {
  const { name } = req.body;

  if (!name) {
    return res.status(400).json({ message: "Product name is required" });
  }

  products.push({ name });

  res.json({
    message: "Product added successfully",
    products
  });
});

app.listen(3002, () => {
  console.log("Product Service running → http://localhost:3002");
});