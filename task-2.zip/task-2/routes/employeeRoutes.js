const express = require("express");
const router = express.Router();
const db = require("../database/db");

/* GET Employees with Sorting & Filtering */
router.get("/employees", (req, res) => {

  const sort = req.query.sort;
  const department = req.query.department;

  let query = "SELECT * FROM employees";
  let params = [];

  /* Filtering */
  if (department) {
    query += " WHERE department = ?";
    params.push(department);
  }

  /* Sorting */
  if (sort === "name") {
    query += " ORDER BY name ASC";
  } else if (sort === "date") {
    query += " ORDER BY joining_date ASC";
  }

  db.query(query, params, (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: "Database error" });
    }
    res.json(result);
  });

});


/* Department Count */
router.get("/department-count", (req, res) => {

  const query = `
    SELECT department, COUNT(*) AS total
    FROM employees
    GROUP BY department
  `;

  db.query(query, (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: "Database error" });
    }
    res.json(result);
  });

});


/* ADD Employee */
router.post("/add-employee", (req, res) => {

  const { name, department, joining_date } = req.body;

  /* Validation */
  if (!name || !department || !joining_date) {
    return res.status(400).json({ error: "All fields are required" });
  }

  const query = `
    INSERT INTO employees (name, department, joining_date)
    VALUES (?, ?, ?)
  `;

  db.query(query, [name, department, joining_date], (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: "Insert failed" });
    }

    res.json({
      message: "Employee added successfully",
      id: result.insertId
    });
  });

});

module.exports = router;