const express = require("express");
const cors = require("cors");
const path = require("path");

const app = express();

const employeeRoutes = require("./routes/employeeRoutes");

app.use(cors());
app.use(express.json());

app.use("/api", employeeRoutes);

app.use(express.static(path.join(__dirname, "public")));

app.listen(3000, () => {
  console.log("Server running on http://localhost:3000");
});