const express = require("express");
const cors = require("cors");

const app = express();

app.use(express.json());
app.use(cors());
app.use(express.static(__dirname));

// In-memory products
let products = [
    { id: 1, name: "Laptop", price: 50000 },
    { id: 2, name: "Phone", price: 20000 }
];

// 🔷 GET
app.get("/products", (req, res) => {
    res.json(products);
});

// 🔷 POST
app.post("/products", (req, res) => {
    const { name, price } = req.body;

    const newProduct = {
        id: products.length + 1,
        name,
        price
    };

    products.push(newProduct);

    res.json({ message: "Product Added ✅" });
});

// 🔷 PUT
app.put("/products/:id", (req, res) => {
    const { name, price } = req.body;

    let product = products.find(p => p.id == req.params.id);

    if (product) {
        product.name = name;
        product.price = price;
        res.json({ message: "Product Updated ✅" });
    } else {
        res.json({ message: "Product Not Found ❌" });
    }
});

// 🔷 DELETE
app.delete("/products/:id", (req, res) => {
    products = products.filter(p => p.id != req.params.id);
    res.json({ message: "Product Deleted ❌" });
});

app.listen(3000, () => {
    console.log("🚀 Server running at http://localhost:3000");
});