const express = require("express");
const cors = require("cors");

const app = express();

app.use(express.json());
app.use(cors());

let users = [];

// ✅ Root route (fixes "Cannot GET /")
app.get("/", (req, res) => {
  res.send("User Service Running ✅");
});

// Get users
app.get("/users", (req, res) => {
  res.json(users);
});

// Add user
app.post("/users", (req, res) => {
  const { name } = req.body;

  if (!name) {
    return res.status(400).json({ message: "Name is required" });
  }

  users.push({ name });

  res.json({
    message: "User added successfully",
    users
  });
});

app.listen(3001, () => {
  console.log("User Service running → http://localhost:3001");
});