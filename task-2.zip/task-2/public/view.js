let sortType = "";

/* Load Employee Data */
function loadData() {

let department = document.getElementById("departmentFilter").value;

fetch(`/api/employees?sort=${sortType}&department=${department}`)
.then(res => res.json())
.then(data => {

let rows = "";

data.forEach(emp => {

let formattedDate = new Date(emp.joining_date).toLocaleDateString();

rows += `
<tr>
<td>${emp.id}</td>
<td>${emp.name}</td>
<td>${emp.department}</td>
<td>${formattedDate}</td>
</tr>
`;

});

document.getElementById("tableData").innerHTML = rows;

})
.catch(err => {
console.error("Error loading data:", err);
});

}

/* Sorting */
function sortName(){
sortType = "name";
loadData();
}

function sortDate(){
sortType = "date";
loadData();
}

/* Filter */
document.getElementById("departmentFilter").addEventListener("change", loadData);

/* Department Count + Stats */
function departmentCount(){

fetch("/api/department-count")
.then(res => res.json())
.then(data => {

let list = "";
let total = 0;
let it = 0;
let hr = 0;

data.forEach(d => {

list += `<li>${d.department}: ${d.total}</li>`;

total += d.total;

if(d.department === "IT") it = d.total;
if(d.department === "HR") hr = d.total;

});

document.getElementById("deptCount").innerHTML = list;

/* Update Dashboard Cards */
document.getElementById("totalEmp").innerText = total;
document.getElementById("itCount").innerText = it;
document.getElementById("hrCount").innerText = hr;

})
.catch(err => {
console.error("Error loading department count:", err);
});

}

/* Initial Load */
loadData();
departmentCount();