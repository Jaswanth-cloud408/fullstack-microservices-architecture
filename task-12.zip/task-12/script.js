async function addProduct() {
    const name = document.getElementById("name").value;
    const price = document.getElementById("price").value;

    await fetch("/products", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, price })
    });

    alert("Product Added");
}

async function loadProducts() {
    const res = await fetch("/products");
    const data = await res.json();

    let html = "<h3>Products</h3>";

    data.forEach(p => {
        html += `
        <p>
            ${p.id}. ${p.name} - ₹${p.price}
            <button onclick="deleteProduct(${p.id})">❌</button>
        </p>`;
    });

    document.getElementById("output").innerHTML = html;
}

async function deleteProduct(id) {
    await fetch(`/products/${id}`, { method: "DELETE" });
    loadProducts();
}